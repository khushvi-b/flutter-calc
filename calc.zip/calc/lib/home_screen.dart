import 'package:calc/provider/cal_provider.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      theme: ThemeData.dark(),
      debugShowCheckedModeBanner: false,
      home: Consumer<CalculatorProvider>(
        builder: (context, provider, _) {
          return Scaffold(
            backgroundColor: Colors.black,
            appBar: AppBar(
              title: Center(child: Text("Calculator App")),
              backgroundColor: Colors.black,
            ),
            body: Column(
              children: [
                CustomTextField(controller: provider.compController ,),
                Container(
                  height: MediaQuery.of(context).size.height / 1.545,
                  width: double.infinity,
                  margin: EdgeInsets.only(top: 40),
                  padding: EdgeInsets.symmetric(horizontal: 25, vertical: 30),
                  decoration: BoxDecoration(
                      color: Colors.grey[900],
                      borderRadius:
                          BorderRadius.vertical(top: Radius.circular(40))),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: List.generate(4, (index) => buttonList[index]),
                      ),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children:
                            List.generate(4, (index) => buttonList[index + 4]),
                      ),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children:
                            List.generate(4, (index) => buttonList[index + 8]),
                      ),
                      Row(
                        children: [
                          Expanded(
                            child: Column(
                              children: [
                                Row(
                                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                  children: List.generate(
                                      3, (index) => buttonList[index + 12]),
                                ),
                                SizedBox(
                                  height: 16,
                                ),
                                Row(
                                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                  children: List.generate(
                                      3, (index) => buttonList[index + 15]),
                                ),
                              ],
                            ),
                          ),
                          SizedBox(
                            width: 20,
                          ),
                          EqualButton()
                        ],
                      )
                    ],
                  ),
                ),
              ],
            ),
          );
        }
      ),
    );
  }
}

class CustomTextField extends StatelessWidget {
  const CustomTextField({super.key, required this.controller});

  final TextEditingController controller;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 25, vertical: 30),
      child: TextField(
        controller: controller,
        decoration: InputDecoration(
            border: InputBorder.none,
            fillColor: Colors.grey[900],
            filled: true),
        style: TextStyle(fontSize: 50),
        readOnly: true,
        autofocus: true,
        showCursor: true,
      ),
    );
  }
}


class EqualButton extends StatelessWidget {
  const EqualButton({super.key});

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: () => Provider.of<CalculatorProvider>(context, listen: false).setValue("="),
      child: Container(
        height: 160,
        width: 60,
        decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(30),
            color: Colors.blue),
        child: Center(
          child: Text(
            "=",
            style: TextStyle(
                fontSize: 35, fontWeight: FontWeight.bold),
          ),
        ),
      ),
    );
  }
}


class Button1 extends StatelessWidget {
  const Button1(
      {super.key, required this.label, this.textColor = Colors.white});

  final String label;
  final Color textColor;

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: () =>
        Provider.of<CalculatorProvider>(context, listen: false).setValue(label),
      child: Material(
        elevation: 10,
        borderRadius: BorderRadius.circular(50),
        child: CircleAvatar(
          radius: 36,
          child: Text(
            label,
            style: TextStyle(
                color: textColor, fontSize: 30, fontWeight: FontWeight.bold),
          ),
          backgroundColor: Colors.grey[850],
        ),
      ),
    );
  }
}

List<Widget> buttonList = [
  Button1(
    label: "C",
    textColor: Colors.blue,
  ),
  Button1(
    label: "/",
    textColor: Colors.blue,
  ),
  Button1(
    label: "X",
    textColor: Colors.blue,
  ),
  Button1(
    label: "AC",
    textColor: Colors.blue,
  ),
  Button1(
    label: "7",
  ),
  Button1(
    label: "8",
  ),
  Button1(
    label: "9",
  ),
  Button1(
    label: "-",
    textColor: Colors.blue,
  ),
  Button1(
    label: "4",
  ),
  Button1(
    label: "5",
  ),
  Button1(
    label: "6",
  ),
  Button1(
    label: "+",
    textColor: Colors.blue,
  ),
  Button1(
    label: "1",
  ),
  Button1(
    label: "2",
  ),
  Button1(
    label: "3",
  ),
  Button1(
    label: "%",
  ),
  Button1(
    label: "0",
  ),
  Button1(
    label: ".",
  ),
];
